## ------------------------------------------------------------------------
library(pho)
setwd("C:/Users/peterh/Documents/pho/extdata")
fars_summarize_years(2013)

## ---- fig.show='hold'----------------------------------------------------
library(maps)
setwd("C:/Users/peterh/Documents/pho/extdata")
fars_map_state(48,2013)

